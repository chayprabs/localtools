#set document(title: "On Local Typesetting", author: "A. Student")
#set page(paper: "a4", margin: 2.5cm, numbering: "1")
#set text(font: "Libertinus Serif", size: 11pt, lang: "en")
#set par(justify: true)
#set heading(numbering: "1.1")
#set math.equation(numbering: "(1)")

#align(center + horizon)[
  #text(24pt, weight: "bold")[On Local Typesetting] \
  #v(1em) A thesis by A. Student
]
#pagebreak()
#outline()
#pagebreak()

#for i in range(1, 9) {
  include "chapters/chapter.typ"
}

#include "chapters/scripts.typ"

#bibliography("refs.bib")
