= Other scripts
Chinese: 排版是一门艺术。 Japanese: 組版は芸術です。 Arabic (right to left): #text(lang: "ar", dir: rtl)[الطباعة فن جميل]. Hebrew: #text(lang: "he", dir: rtl)[סדר דפוס].
