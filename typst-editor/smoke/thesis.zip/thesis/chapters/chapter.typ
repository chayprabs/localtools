= A chapter on typesetting
#lorem(220) @knuth1984

== Measurements
#figure(image("/figures/bars.svg", width: 60%), caption: [Compile times.])
#lorem(160) @lamport1994

$ f(x) = sum_(n=0)^oo (f^((n))(a))/(n!) (x - a)^n $

#figure(table(columns: 4, ..range(16).map(i => [#i])), caption: [A table.])
#lorem(200)
#pagebreak(weak: true)
