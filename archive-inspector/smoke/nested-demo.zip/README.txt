Archive Inspector demo archive.
It nests a tar.gz inside a zip, and a zip inside that.
